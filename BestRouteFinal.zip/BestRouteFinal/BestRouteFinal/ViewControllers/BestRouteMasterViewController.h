//
//  BestRouteMasterViewController.h
//  BestRouteFinal
//
//  Created by Jesse Nelson on 11/1/13.
//  Copyright (c) 2013 Jesse Nelson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RouteViewController.h"
#import "BestRouteBrain.h"
#import "MapViewController.h"
@interface BestRouteMasterViewController : UITableViewController
<UIAlertViewDelegate> {
    BestRouteBrain *brain;
}

@end
